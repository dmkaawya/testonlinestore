"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { 
  ShoppingCart, 
  Heart, 
  Star, 
  Truck, 
  Shield, 
  RotateCcw, 
  Minus, 
  Plus,
  Share2,
  ChevronLeft,
  User,
  Calendar,
  MessageCircle
} from "lucide-react"
import Link from "next/link"
import { useParams } from "next/navigation"

interface Product {
  id: string
  name: string
  shortTitle1?: string
  shortTitle2?: string
  shortTitle3?: string
  shortTitle4?: string
  shortTitle5?: string
  shortTitle6?: string
  description?: string
  price: number
  marketPrice?: number
  discount?: number
  color?: string
  size?: string
  stock: number
  image?: string
  image2?: string
  image3?: string
  image4?: string
  image5?: string
  image6?: string
  deliveryInfo?: string
  category?: { name: string }
  reviews?: Array<{
    id: string
    userName: string
    rating: number
    comment?: string
    createdAt: string
  }>
}

export default function ProductDetailPage() {
  const params = useParams()
  const [quantity, setQuantity] = useState(1)
  const [selectedImage, setSelectedImage] = useState(0)
  const [selectedVariant, setSelectedVariant] = useState("")
  const [product, setProduct] = useState<Product | null>(null)
  const [loading, setLoading] = useState(true)
  const [reviewData, setReviewData] = useState({
    userName: "",
    rating: 5,
    comment: ""
  })

  useEffect(() => {
    fetchProduct()
  }, [params.id])

  const fetchProduct = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/products/${params.id}`)
      const data = await response.json()
      setProduct(data)
    } catch (error) {
      console.error('Error fetching product:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddToCart = () => {
    if (!product) return
    
    // Add to cart logic here
    const cartItem = {
      productId: product.id,
      name: product.name,
      price: product.price,
      quantity: quantity,
      image: product.image
    }
    
    // Get existing cart or create new one
    const existingCart = JSON.parse(localStorage.getItem('cart') || '[]')
    const existingItemIndex = existingCart.findIndex((item: any) => item.productId === product.id)
    
    if (existingItemIndex >= 0) {
      existingCart[existingItemIndex].quantity += quantity
    } else {
      existingCart.push(cartItem)
    }
    
    localStorage.setItem('cart', JSON.stringify(existingCart))
    
    // Update cart count in header (you might want to use context for this)
    window.dispatchEvent(new Event('cartUpdated'))
    
    alert('Product added to cart!')
  }

  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!product || !reviewData.userName.trim()) return

    try {
      const response = await fetch(`/api/products/${product.id}/reviews`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(reviewData)
      })

      if (response.ok) {
        setReviewData({ userName: "", rating: 5, comment: "" })
        fetchProduct() // Refresh product to get new review
        alert('Review submitted successfully!')
      }
    } catch (error) {
      console.error('Error submitting review:', error)
      alert('Failed to submit review')
    }
  }

  const images = product ? [
    product.image,
    product.image2,
    product.image3,
    product.image4,
    product.image5,
    product.image6
  ].filter(Boolean) : []

  const relatedProducts = [
    {
      id: "2",
      name: "Smart Watch Pro",
      price: 399.99,
      image: "/api/placeholder/300/300",
      rating: 4.8
    },
    {
      id: "3",
      name: "4K Webcam",
      price: 149.99,
      image: "/api/placeholder/300/300",
      rating: 4.3
    },
    {
      id: "4",
      name: "Mechanical Keyboard",
      price: 129.99,
      image: "/api/placeholder/300/300",
      rating: 4.7
    }
  ]

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Loading product...</p>
        </div>
      </div>
    )
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Product not found</h1>
          <Button asChild>
            <Link href="/products">
              <ChevronLeft className="h-4 w-4 mr-2" />
              Back to Products
            </Link>
          </Button>
        </div>
      </div>
    )
  }

  const discountPercentage = product.marketPrice && product.marketPrice > product.price 
    ? Math.round(((product.marketPrice - product.price) / product.marketPrice) * 100)
    : 0

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/" className="text-2xl font-bold text-primary">
                RU Online Store
              </Link>
              <nav className="hidden md:flex items-center space-x-6">
                <Link href="/products" className="text-sm font-medium hover:text-primary transition-colors">
                  Products
                </Link>
                <Link href="/categories" className="text-sm font-medium hover:text-primary transition-colors">
                  Categories
                </Link>
                <Link href="/deals" className="text-sm font-medium hover:text-primary transition-colors">
                  Deals
                </Link>
                <Link href="/contact" className="text-sm font-medium hover:text-primary transition-colors">
                  Contact
                </Link>
              </nav>
            </div>

            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon">
                <Heart className="h-5 w-5" />
              </Button>
              
              <Button variant="ghost" size="icon" className="relative">
                <ShoppingCart className="h-5 w-5" />
              </Button>
              
              <Button variant="ghost" size="icon">
                <User className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Breadcrumb */}
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
          <Link href="/" className="hover:text-primary">Home</Link>
          <ChevronLeft className="h-4 w-4 rotate-180" />
          <Link href="/products" className="hover:text-primary">Products</Link>
          <ChevronLeft className="h-4 w-4 rotate-180" />
          {product.category && (
            <>
              <Link href={`/categories/${product.category.name.toLowerCase()}`} className="hover:text-primary">
                {product.category.name}
              </Link>
              <ChevronLeft className="h-4 w-4 rotate-180" />
            </>
          )}
          <span className="text-foreground">{product.name}</span>
        </div>
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-12">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="aspect-square bg-muted rounded-lg overflow-hidden">
              {images[selectedImage] ? (
                <img
                  src={images[selectedImage] || ''}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <span className="text-8xl">📦</span>
                </div>
              )}
            </div>
            
            {/* Thumbnail Gallery */}
            {images.length > 1 && (
              <div className="grid grid-cols-6 gap-2">
                {images.map((image, index) => (
                  <button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    className={`aspect-square bg-muted rounded border-2 transition-colors ${
                      selectedImage === index ? "border-primary" : "border-transparent"
                    }`}
                  >
                    {image ? (
                      <img
                        src={image}
                        alt={`${product.name} ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <span className="text-lg">📦</span>
                      </div>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
                  
                  {/* Short Titles */}
                  <div className="space-y-1 mb-4">
                    {product.shortTitle1 && (
                      <p className="text-lg text-muted-foreground">• {product.shortTitle1}</p>
                    )}
                    {product.shortTitle2 && (
                      <p className="text-lg text-muted-foreground">• {product.shortTitle2}</p>
                    )}
                    {product.shortTitle3 && (
                      <p className="text-lg text-muted-foreground">• {product.shortTitle3}</p>
                    )}
                    {product.shortTitle4 && (
                      <p className="text-lg text-muted-foreground">• {product.shortTitle4}</p>
                    )}
                    {product.shortTitle5 && (
                      <p className="text-lg text-muted-foreground">• {product.shortTitle5}</p>
                    )}
                    {product.shortTitle6 && (
                      <p className="text-lg text-muted-foreground">• {product.shortTitle6}</p>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-4 mb-4">
                    <div className="flex items-center gap-2">
                      <span className="text-3xl font-bold text-primary">
                        Rs.{product.price.toFixed(2)}
                      </span>
                      {product.marketPrice && product.marketPrice > product.price && (
                        <span className="text-lg text-muted-foreground line-through">
                          Rs.{product.marketPrice.toFixed(2)}
                        </span>
                      )}
                      {discountPercentage > 0 && (
                        <Badge className="bg-red-500 hover:bg-red-500">
                          {discountPercentage}% OFF
                        </Badge>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-4 mb-4">
                    {product.color && (
                      <div className="flex items-center gap-2">
                        <span className="font-medium">Color:</span>
                        <span>{product.color}</span>
                      </div>
                    )}
                    {product.size && (
                      <div className="flex items-center gap-2">
                        <span className="font-medium">Size:</span>
                        <span>{product.size}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <span className="font-medium">Stock:</span>
                      <span className={product.stock > 0 ? "text-green-600" : "text-red-600"}>
                        {product.stock > 0 ? `${product.stock} available` : "Out of stock"}
                      </span>
                    </div>
                  </div>
                </div>
                
                <Button variant="ghost" size="icon">
                  <Share2 className="h-5 w-5" />
                </Button>
              </div>
            </div>

            {/* Quantity */}
            <div>
              <h3 className="font-semibold mb-3">Quantity</h3>
              <div className="flex items-center gap-3">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  disabled={quantity <= 1}
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <Input
                  type="number"
                  value={quantity}
                  onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-20 text-center"
                  min={1}
                  max={product.stock}
                />
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setQuantity(Math.min(product.stock, quantity + 1))}
                  disabled={quantity >= product.stock}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              <Button 
                className="w-full" 
                size="lg"
                onClick={handleAddToCart}
                disabled={product.stock === 0}
              >
                <ShoppingCart className="h-5 w-5 mr-2" />
                {product.stock === 0 ? "Out of Stock" : "Add to Cart"}
              </Button>
              
              <div className="flex gap-3">
                <Button variant="outline" className="flex-1">
                  <Heart className="h-4 w-4 mr-2" />
                  Wishlist
                </Button>
                <Button variant="outline" className="flex-1" asChild>
                  <Link href="/checkout">
                    Buy Now
                  </Link>
                </Button>
              </div>
            </div>

            {/* Delivery Info */}
            {product.deliveryInfo && (
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <Truck className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium">Delivery Information</p>
                      <p className="text-sm text-muted-foreground">{product.deliveryInfo}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Contact Info */}
            <Card>
              <CardContent className="p-4 space-y-3">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">📞</span>
                  <div>
                    <p className="font-medium">Hotline</p>
                    <p className="text-sm text-muted-foreground">765767113</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">📱</span>
                  <div>
                    <p className="font-medium">WhatsApp</p>
                    <p className="text-sm text-muted-foreground">+94 77 504 8455</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-2xl">✉️</span>
                  <div>
                    <p className="font-medium">Email</p>
                    <p className="text-sm text-muted-foreground">ru.online.stores@gmail.com</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Product Details Tabs */}
        <div className="mb-12">
          <Tabs defaultValue="description" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="description">Description</TabsTrigger>
              <TabsTrigger value="specifications">Specifications</TabsTrigger>
              <TabsTrigger value="reviews">Reviews ({product.reviews?.length || 0})</TabsTrigger>
            </TabsList>
            
            <TabsContent value="description" className="mt-6">
              <div className="prose max-w-none">
                <p>{product.description || "No description available for this product."}</p>
                {product.deliveryInfo && (
                  <div className="mt-6 p-4 bg-muted rounded-lg">
                    <h4 className="font-semibold mb-2">Delivery Information</h4>
                    <p>{product.deliveryInfo}</p>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="specifications" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex justify-between py-2 border-b">
                  <span className="font-medium">Product Name</span>
                  <span>{product.name}</span>
                </div>
                {product.shortTitle1 && (
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Feature 1</span>
                    <span>{product.shortTitle1}</span>
                  </div>
                )}
                {product.shortTitle2 && (
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Feature 2</span>
                    <span>{product.shortTitle2}</span>
                  </div>
                )}
                <div className="flex justify-between py-2 border-b">
                  <span className="font-medium">Price</span>
                  <span>Rs.{product.price.toFixed(2)}</span>
                </div>
                {product.marketPrice && (
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Market Price</span>
                    <span>Rs.{product.marketPrice.toFixed(2)}</span>
                  </div>
                )}
                {product.color && (
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Color</span>
                    <span>{product.color}</span>
                  </div>
                )}
                {product.size && (
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Size</span>
                    <span>{product.size}</span>
                  </div>
                )}
                <div className="flex justify-between py-2 border-b">
                  <span className="font-medium">Stock</span>
                  <span>{product.stock} units</span>
                </div>
                {product.category && (
                  <div className="flex justify-between py-2 border-b">
                    <span className="font-medium">Category</span>
                    <span>{product.category.name}</span>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="reviews" className="mt-6">
              <div className="space-y-6">
                {/* Review Form */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <MessageCircle className="h-5 w-5" />
                      Write a Review
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <form onSubmit={handleSubmitReview} className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">Your Name</label>
                        <Input
                          value={reviewData.userName}
                          onChange={(e) => setReviewData(prev => ({ ...prev, userName: e.target.value }))}
                          placeholder="Enter your name"
                          required
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium mb-2">Rating</label>
                        <Select 
                          value={reviewData.rating.toString()} 
                          onValueChange={(value) => setReviewData(prev => ({ ...prev, rating: parseInt(value) }))}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="5">⭐⭐⭐⭐⭐ (5 stars)</SelectItem>
                            <SelectItem value="4">⭐⭐⭐⭐ (4 stars)</SelectItem>
                            <SelectItem value="3">⭐⭐⭐ (3 stars)</SelectItem>
                            <SelectItem value="2">⭐⭐ (2 stars)</SelectItem>
                            <SelectItem value="1">⭐ (1 star)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium mb-2">Comment (Optional)</label>
                        <textarea
                          value={reviewData.comment}
                          onChange={(e) => setReviewData(prev => ({ ...prev, comment: e.target.value }))}
                          placeholder="Share your experience with this product..."
                          className="w-full p-3 border rounded-md min-h-[100px] resize-none"
                        />
                      </div>
                      
                      <Button type="submit">Submit Review</Button>
                    </form>
                  </CardContent>
                </Card>

                {/* Reviews List */}
                {product.reviews && product.reviews.length > 0 ? (
                  <div className="space-y-4">
                    {product.reviews.map((review) => (
                      <Card key={review.id}>
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between mb-3">
                            <div>
                              <div className="flex items-center gap-2 mb-1">
                                <span className="font-medium">{review.userName}</span>
                                <div className="flex items-center">
                                  {[...Array(5)].map((_, i) => (
                                    <Star 
                                      key={i} 
                                      className={`h-4 w-4 ${
                                        i < review.rating 
                                          ? "fill-yellow-400 text-yellow-400" 
                                          : "text-gray-300"
                                      }`} 
                                    />
                                  ))}
                                </div>
                              </div>
                              <p className="text-sm text-muted-foreground">
                                {new Date(review.createdAt).toLocaleDateString('en-US', {
                                  year: 'numeric',
                                  month: 'long',
                                  day: 'numeric'
                                })}
                              </p>
                            </div>
                          </div>
                          {review.comment && (
                            <p className="text-muted-foreground">{review.comment}</p>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <MessageCircle className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">No reviews yet. Be the first to review this product!</p>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Related Products */}
        <div>
          <h2 className="text-2xl font-bold mb-6">Related Products</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {relatedProducts.map((relatedProduct) => (
              <Card key={relatedProduct.id} className="group hover:shadow-lg transition-shadow">
                <CardHeader className="p-0">
                  <div className="aspect-square bg-muted rounded-t-lg flex items-center justify-center">
                    <span className="text-6xl">📦</span>
                  </div>
                </CardHeader>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-2 line-clamp-2">{relatedProduct.name}</h3>
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star 
                          key={i} 
                          className={`h-4 w-4 ${
                            i < Math.floor(relatedProduct.rating) 
                              ? "fill-yellow-400 text-yellow-400" 
                              : "text-gray-300"
                          }`} 
                        />
                      ))}
                    </div>
                    <span className="text-sm text-muted-foreground">
                      ({relatedProduct.rating})
                    </span>
                  </div>
                  <p className="text-xl font-bold text-primary mb-3">
                    Rs.{relatedProduct.price.toFixed(2)}
                  </p>
                  <Button className="w-full" size="sm">
                    Add to Cart
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}