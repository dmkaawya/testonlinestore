import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '12')
    const search = searchParams.get('search') || ''
    const category = searchParams.get('category') || ''
    const sortBy = searchParams.get('sortBy') || 'createdAt'
    const sortOrder = searchParams.get('sortOrder') || 'desc'

    const skip = (page - 1) * limit

    // Build where clause
    const where: any = {}
    
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { shortTitle1: { contains: search, mode: 'insensitive' } },
        { shortTitle2: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } }
      ]
    }

    if (category && category !== 'all') {
      where.category = {
        name: { contains: category, mode: 'insensitive' }
      }
    }

    // Build orderBy
    const orderBy: any = {}
    orderBy[sortBy] = sortOrder

    const [products, total] = await Promise.all([
      db.product.findMany({
        where,
        include: {
          category: true,
          reviews: true
        },
        orderBy,
        skip,
        take: limit
      }),
      db.product.count({ where })
    ])

    return NextResponse.json({
      products,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    })
  } catch (error) {
    console.error('Error fetching products:', error)
    return NextResponse.json(
      { error: 'Failed to fetch products' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    const product = await db.product.create({
      data: {
        name: body.name,
        shortTitle1: body.shortTitle1,
        shortTitle2: body.shortTitle2,
        shortTitle3: body.shortTitle3,
        shortTitle4: body.shortTitle4,
        shortTitle5: body.shortTitle5,
        shortTitle6: body.shortTitle6,
        description: body.description,
        price: parseFloat(body.price),
        marketPrice: body.marketPrice ? parseFloat(body.marketPrice) : null,
        discount: body.discount ? parseFloat(body.discount) : 0,
        color: body.color,
        size: body.size,
        stock: parseInt(body.stock) || 0,
        image: body.image,
        image2: body.image2,
        image3: body.image3,
        image4: body.image4,
        image5: body.image5,
        image6: body.image6,
        categoryId: body.categoryId,
        deliveryInfo: body.deliveryInfo
      },
      include: {
        category: true,
        reviews: true
      }
    })

    return NextResponse.json(product, { status: 201 })
  } catch (error) {
    console.error('Error creating product:', error)
    return NextResponse.json(
      { error: 'Failed to create product' },
      { status: 500 }
    )
  }
}