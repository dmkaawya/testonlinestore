import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const product = await db.product.findUnique({
      where: { id: params.id },
      include: {
        category: true,
        reviews: {
          orderBy: { createdAt: 'desc' }
        }
      }
    })

    if (!product) {
      return NextResponse.json(
        { error: 'Product not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(product)
  } catch (error) {
    console.error('Error fetching product:', error)
    return NextResponse.json(
      { error: 'Failed to fetch product' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    
    const product = await db.product.update({
      where: { id: params.id },
      data: {
        name: body.name,
        shortTitle1: body.shortTitle1,
        shortTitle2: body.shortTitle2,
        shortTitle3: body.shortTitle3,
        shortTitle4: body.shortTitle4,
        shortTitle5: body.shortTitle5,
        shortTitle6: body.shortTitle6,
        description: body.description,
        price: parseFloat(body.price),
        marketPrice: body.marketPrice ? parseFloat(body.marketPrice) : null,
        discount: body.discount ? parseFloat(body.discount) : 0,
        color: body.color,
        size: body.size,
        stock: parseInt(body.stock) || 0,
        image: body.image,
        image2: body.image2,
        image3: body.image3,
        image4: body.image4,
        image5: body.image5,
        image6: body.image6,
        categoryId: body.categoryId,
        deliveryInfo: body.deliveryInfo
      },
      include: {
        category: true,
        reviews: true
      }
    })

    return NextResponse.json(product)
  } catch (error) {
    console.error('Error updating product:', error)
    return NextResponse.json(
      { error: 'Failed to update product' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await db.product.delete({
      where: { id: params.id }
    })

    return NextResponse.json({ message: 'Product deleted successfully' })
  } catch (error) {
    console.error('Error deleting product:', error)
    return NextResponse.json(
      { error: 'Failed to delete product' },
      { status: 500 }
    )
  }
}