import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')

    const skip = (page - 1) * limit

    const [orders, total] = await Promise.all([
      db.order.findMany({
        include: {
          items: {
            include: {
              product: true
            }
          },
          user: {
            select: {
              id: true,
              name: true,
              email: true
            }
          }
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit
      }),
      db.order.count()
    ])

    return NextResponse.json({
      orders,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    })
  } catch (error) {
    console.error('Error fetching orders:', error)
    return NextResponse.json(
      { error: 'Failed to fetch orders' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    const order = await db.order.create({
      data: {
        customerType: body.customerType,
        customerName: body.customerName,
        customerPhone: body.customerPhone,
        customerAddress: body.customerAddress,
        customerDistrict: body.customerDistrict,
        customerProvince: body.customerProvince,
        shopName: body.shopName,
        shopWhatsApp: body.shopWhatsApp,
        total: parseFloat(body.total),
        profit: body.profit ? parseFloat(body.profit) : 0,
        items: {
          create: body.items.map((item: any) => ({
            productId: item.productId,
            quantity: item.quantity,
            price: item.price
          }))
        }
      },
      include: {
        items: {
          include: {
            product: true
          }
        }
      }
    })

    // Send WhatsApp message
    await sendWhatsAppMessage(order)

    return NextResponse.json(order, { status: 201 })
  } catch (error) {
    console.error('Error creating order:', error)
    return NextResponse.json(
      { error: 'Failed to create order' },
      { status: 500 }
    )
  }
}

async function sendWhatsAppMessage(order: any) {
  try {
    const shopDetails = {
      name: "RU Online Store",
      location: "Kalutara, Sri Lanka",
      support: "+94 77 504 8455",
      email: "ru.online.stores@gmail.com",
      hotline: "765767113"
    }

    let message = `🛒 *NEW ORDER - ${shopDetails.name}* 🛒\n\n`
    
    if (order.customerType === 'RETAIL') {
      message += `👤 *Customer Details:*\n`
      message += `Name: ${order.customerName}\n`
      message += `Phone: ${order.customerPhone}\n`
      message += `Address: ${order.customerAddress}\n`
      message += `District: ${order.customerDistrict}\n`
      message += `Province: ${order.customerProvince}\n\n`
    } else {
      message += `🏪 *Dropshipping Details:*\n`
      message += `Shop Name: ${order.shopName}\n`
      message += `WhatsApp: ${order.shopWhatsApp}\n`
      message += `Customer Name: ${order.customerName}\n`
      message += `Customer Phone: ${order.customerPhone}\n\n`
    }

    message += `📦 *Order Items:*\n`
    order.items.forEach((item: any, index: number) => {
      message += `${index + 1}. ${item.product.name}\n`
      message += `   Quantity: ${item.quantity}\n`
      message += `   Price: Rs.${item.price.toFixed(2)}\n`
      message += `   Total: Rs.${(item.quantity * item.price).toFixed(2)}\n\n`
    })

    message += `💰 *Payment Details:*\n`
    message += `Subtotal: Rs.${order.total.toFixed(2)}\n`
    if (order.profit > 0) {
      message += `Profit: Rs.${order.profit.toFixed(2)}\n`
    }
    message += `Status: ${order.status}\n\n`

    message += `📞 *Contact Information:*\n`
    message += `Shop: ${shopDetails.name}\n`
    message += `Location: ${shopDetails.location}\n`
    message += `Support: ${shopDetails.support}\n`
    message += `Hotline: ${shopDetails.hotline}\n`
    message += `Email: ${shopDetails.email}\n\n`

    message += `🕐 *Order Time:*\n`
    message += `${new Date(order.createdAt).toLocaleString('en-US', { 
      timeZone: 'Asia/Colombo' 
    })}\n\n`

    message += `Thank you for your order! 🙏`

    // Here you would integrate with a WhatsApp API service
    // For now, we'll just log the message
    console.log('WhatsApp Message:', message)
    
    // You can use services like:
    // - Twilio WhatsApp API
    // - WhatsApp Business API
    // - Third-party services like CallMeBot or similar
    
    // Example using a hypothetical WhatsApp API:
    /*
    const response = await fetch('https://api.whatsapp-service.com/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.WHATSAPP_API_KEY}`
      },
      body: JSON.stringify({
        to: shopDetails.support.replace('+', ''),
        message: message
      })
    })
    */
    
  } catch (error) {
    console.error('Error sending WhatsApp message:', error)
  }
}