import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";
import { CartProvider } from "@/lib/cart-context";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "RU Online Store - Your Trusted Shopping Destination in Sri Lanka",
  description: "Quality products at unbeatable prices with fast delivery across Sri Lanka. Shop electronics, fashion, home goods and more.",
  keywords: ["RU Online Store", "Sri Lanka", "online shopping", "electronics", "fashion", "home goods", "Kalutara"],
  authors: [{ name: "RU Online Store" }],
  openGraph: {
    title: "RU Online Store - Sri Lanka",
    description: "Your trusted online shopping destination in Kalutara, Sri Lanka",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <CartProvider>
          {children}
          <Toaster />
        </CartProvider>
      </body>
    </html>
  );
}
