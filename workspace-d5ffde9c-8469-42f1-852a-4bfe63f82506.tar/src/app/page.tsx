"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, ShoppingCart, User, Heart, Star, Truck, Shield, RotateCcw, Filter, Grid, List } from "lucide-react"
import Link from "next/link"
import { useCart } from "@/lib/cart-context"
import { toast } from "sonner"

interface Product {
  id: string
  name: string
  shortTitle1?: string
  shortTitle2?: string
  price: number
  marketPrice?: number
  discount?: number
  color?: string
  size?: string
  stock: number
  image?: string
  image2?: string
  image3?: string
  category?: string
}

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("")
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [viewMode, setViewMode] = useState("grid")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [sortBy, setSortBy] = useState("latest")
  
  const { state, addItem } = useCart()

  const categories = [
    "all", "Electronics", "Fashion", "Home & Garden", 
    "Sports", "Books", "Toys", "Beauty", "Automotive"
  ]

  useEffect(() => {
    fetchProducts()
  }, [])

  const fetchProducts = async () => {
    try {
      setLoading(true)
      const response = await fetch('/api/products?limit=12')
      const data = await response.json()
      setProducts(data.products || [])
    } catch (error) {
      console.error('Error fetching products:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleAddToCart = (product: Product) => {
    addItem({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      color: product.color,
      size: product.size
    })
    toast.success(`${product.name} added to cart!`)
  }

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         (product.shortTitle1 && product.shortTitle1.toLowerCase().includes(searchQuery.toLowerCase())) ||
                         (product.shortTitle2 && product.shortTitle2.toLowerCase().includes(searchQuery.toLowerCase()))
    const matchesCategory = selectedCategory === "all" || product.category === selectedCategory
    
    return matchesSearch && matchesCategory
  })

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-low":
        return a.price - b.price
      case "price-high":
        return b.price - a.price
      case "name":
        return a.name.localeCompare(b.name)
      default:
        return 0
    }
  })

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/" className="text-2xl font-bold text-primary">
                RU Online Store
              </Link>
              <nav className="hidden md:flex items-center space-x-6">
                <Link href="/products" className="text-sm font-medium hover:text-primary transition-colors">
                  Products
                </Link>
                <Link href="/categories" className="text-sm font-medium hover:text-primary transition-colors">
                  Categories
                </Link>
                <Link href="/deals" className="text-sm font-medium hover:text-primary transition-colors">
                  Deals
                </Link>
                <Link href="/contact" className="text-sm font-medium hover:text-primary transition-colors">
                  Contact
                </Link>
              </nav>
            </div>

            <div className="flex items-center space-x-4">
              <div className="hidden md:flex relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
                <Input
                  placeholder="Search products..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 w-64"
                />
              </div>
              
              <Button variant="ghost" size="icon">
                <Heart className="h-5 w-5" />
              </Button>
              
              <Button variant="ghost" size="icon" className="relative">
                <ShoppingCart className="h-5 w-5" />
                {state.itemCount > 0 && (
                  <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                    {state.itemCount}
                  </Badge>
                )}
              </Button>
              
              <Button variant="ghost" size="icon">
                <User className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-primary/10 to-primary/5 py-20 md:py-32">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-4xl md:text-6xl font-bold text-foreground leading-tight">
                Welcome to RU Online Store
              </h1>
              <p className="text-lg text-muted-foreground max-w-md">
                Your trusted online shopping destination in Sri Lanka. Quality products at unbeatable prices with fast delivery.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="text-lg px-8 py-6" asChild>
                  <Link href="/products">Shop Now</Link>
                </Button>
                <Button variant="outline" size="lg" className="text-lg px-8 py-6" asChild>
                  <Link href="/contact">Contact Us</Link>
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="bg-gradient-to-br from-primary/20 to-primary/10 rounded-2xl p-8">
                <div className="aspect-square bg-muted rounded-xl flex items-center justify-center">
                  <span className="text-6xl">🛍️</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Shop Info */}
      <section className="py-16 bg-muted/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Shop With Us?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              We offer the best shopping experience with quality products and excellent service
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Truck className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Fast Delivery</h3>
              <p className="text-muted-foreground">
                Quick delivery across Sri Lanka
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Quality Products</h3>
              <p className="text-muted-foreground">
                100% genuine products guaranteed
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <RotateCcw className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Easy Returns</h3>
              <p className="text-muted-foreground">
                7-day return policy
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
            <div>
              <h2 className="text-3xl font-bold mb-2">Featured Products</h2>
              <p className="text-muted-foreground">
                Discover our latest collection of quality products
              </p>
            </div>
            
            <div className="flex items-center gap-4">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category === "all" ? "All Categories" : category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="latest">Latest</SelectItem>
                  <SelectItem value="price-low">Price: Low</SelectItem>
                  <SelectItem value="price-high">Price: High</SelectItem>
                  <SelectItem value="name">Name</SelectItem>
                </SelectContent>
              </Select>
              
              <div className="flex items-center gap-2">
                <Button
                  variant={viewMode === "grid" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setViewMode("grid")}
                >
                  <Grid className="h-4 w-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setViewMode("list")}
                >
                  <List className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>

          {/* Mobile Search */}
          <div className="md:hidden mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search products..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          {/* Products Grid/List */}
          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {[...Array(8)].map((_, index) => (
                <Card key={index} className="animate-pulse">
                  <div className="aspect-square bg-muted rounded-t-lg"></div>
                  <CardContent className="p-4 space-y-3">
                    <div className="h-4 bg-muted rounded"></div>
                    <div className="h-4 bg-muted rounded w-3/4"></div>
                    <div className="h-6 bg-muted rounded w-1/2"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <>
              {viewMode === "grid" ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {sortedProducts.map((product) => (
                    <Card key={product.id} className="group hover:shadow-lg transition-all duration-300 hover:scale-105">
                      <CardHeader className="p-0">
                        <div className="relative">
                          <div className="aspect-square bg-muted rounded-t-lg flex items-center justify-center overflow-hidden">
                            {product.image ? (
                              <img 
                                src={product.image} 
                                alt={product.name}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <span className="text-6xl">📦</span>
                            )}
                          </div>
                          
                          {product.discount && product.discount > 0 && (
                            <Badge className="absolute top-2 left-2 bg-red-500 hover:bg-red-500">
                              {product.discount}% OFF
                            </Badge>
                          )}
                          
                          {product.stock === 0 && (
                            <Badge variant="destructive" className="absolute top-2 left-2">
                              Out of Stock
                            </Badge>
                          )}
                          
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity bg-white/80 hover:bg-white"
                          >
                            <Heart className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardHeader>
                      <CardContent className="p-4">
                        <div className="space-y-2 mb-3">
                          <h3 className="font-semibold line-clamp-2 text-sm">{product.name}</h3>
                          {product.shortTitle1 && (
                            <p className="text-xs text-muted-foreground line-clamp-1">
                              {product.shortTitle1}
                            </p>
                          )}
                        </div>
                        
                        <div className="flex items-center gap-2 mb-2">
                          {product.color && (
                            <div className="flex items-center gap-1">
                              <span className="text-xs text-muted-foreground">Color:</span>
                              <span className="text-xs font-medium">{product.color}</span>
                            </div>
                          )}
                          {product.size && (
                            <div className="flex items-center gap-1">
                              <span className="text-xs text-muted-foreground">Size:</span>
                              <span className="text-xs font-medium">{product.size}</span>
                            </div>
                          )}
                        </div>
                        
                        <div className="flex items-center gap-2 mb-3">
                          <p className="text-lg font-bold text-primary">
                            Rs.{product.price.toFixed(2)}
                          </p>
                          {product.marketPrice && product.marketPrice > product.price && (
                            <p className="text-sm text-muted-foreground line-through">
                              Rs.{product.marketPrice.toFixed(2)}
                            </p>
                          )}
                        </div>
                        
                        <div className="text-xs text-muted-foreground mb-3">
                          Stock: {product.stock > 0 ? `${product.stock} available` : 'Out of stock'}
                        </div>
                      </CardContent>
                      <CardFooter className="p-4 pt-0">
                        <div className="flex gap-2 w-full">
                          <Button 
                            className="flex-1" 
                            size="sm"
                            disabled={product.stock === 0}
                            asChild
                          >
                            <Link href={`/products/${product.id}`}>
                              View Details
                            </Link>
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            disabled={product.stock === 0}
                            onClick={() => handleAddToCart(product)}
                          >
                            <ShoppingCart className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="space-y-4">
                  {sortedProducts.map((product) => (
                    <Card key={product.id}>
                      <CardContent className="p-6">
                        <div className="flex gap-6">
                          <div className="w-32 h-32 bg-muted rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden">
                            {product.image ? (
                              <img 
                                src={product.image} 
                                alt={product.name}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <span className="text-4xl">📦</span>
                            )}
                          </div>
                          <div className="flex-1">
                            <div className="flex justify-between items-start mb-2">
                              <div>
                                <h3 className="text-lg font-semibold">{product.name}</h3>
                                {product.shortTitle1 && (
                                  <p className="text-sm text-muted-foreground mb-2">
                                    {product.shortTitle1}
                                  </p>
                                )}
                                <div className="flex items-center gap-4 mb-3">
                                  {product.color && (
                                    <span className="text-sm">Color: {product.color}</span>
                                  )}
                                  {product.size && (
                                    <span className="text-sm">Size: {product.size}</span>
                                  )}
                                  <span className={`text-sm ${product.stock > 0 ? 'text-green-600' : 'text-red-600'}`}>
                                    Stock: {product.stock}
                                  </span>
                                </div>
                              </div>
                              <div className="flex gap-2">
                                {product.discount && product.discount > 0 && (
                                  <Badge className="bg-red-500 hover:bg-red-500">
                                    {product.discount}% OFF
                                  </Badge>
                                )}
                                {product.stock === 0 && (
                                  <Badge variant="destructive">Out of Stock</Badge>
                                )}
                              </div>
                            </div>
                            
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <p className="text-xl font-bold text-primary">
                                  Rs.{product.price.toFixed(2)}
                                </p>
                                {product.marketPrice && product.marketPrice > product.price && (
                                  <p className="text-sm text-muted-foreground line-through">
                                    Rs.{product.marketPrice.toFixed(2)}
                                  </p>
                                )}
                              </div>
                              <div className="flex gap-2">
                                <Button 
                                  disabled={product.stock === 0}
                                  asChild
                                >
                                  <Link href={`/products/${product.id}`}>
                                    View Details
                                  </Link>
                                </Button>
                                <Button 
                                  variant="outline"
                                  disabled={product.stock === 0}
                                  onClick={() => handleAddToCart(product)}
                                >
                                  <ShoppingCart className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              {sortedProducts.length === 0 && (
                <div className="text-center py-12">
                  <h3 className="text-lg font-semibold mb-2">No products found</h3>
                  <p className="text-muted-foreground">
                    Try adjusting your search or filters
                  </p>
                </div>
              )}
            </>
          )}
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-muted/50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Contact Us</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Get in touch with us for any inquiries or support
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">📞</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Hotline</h3>
              <p className="text-muted-foreground mb-2">765767113</p>
              <p className="text-sm text-muted-foreground">24/7 Available</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">📱</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">WhatsApp</h3>
              <p className="text-muted-foreground mb-2">+94 77 504 8455</p>
              <p className="text-sm text-muted-foreground">Instant Support</p>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl">✉️</span>
              </div>
              <h3 className="text-xl font-semibold mb-2">Email</h3>
              <p className="text-muted-foreground mb-2">ru.online.stores@gmail.com</p>
              <p className="text-sm text-muted-foreground">Quick Response</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-muted py-12 mt-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4">RU Online Store</h3>
              <p className="text-muted-foreground mb-4">
                Your trusted online shopping destination in Kalutara, Sri Lanka.
              </p>
              <div className="space-y-2 text-sm text-muted-foreground">
                <p>📍 Kalutara, Sri Lanka</p>
                <p>📞 Hotline: 765767113</p>
                <p>📱 Support: +94 77 504 8455</p>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><Link href="/products" className="hover:text-primary">Products</Link></li>
                <li><Link href="/categories" className="hover:text-primary">Categories</Link></li>
                <li><Link href="/deals" className="hover:text-primary">Deals</Link></li>
                <li><Link href="/contact" className="hover:text-primary">Contact</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Customer Service</h4>
              <ul className="space-y-2 text-muted-foreground">
                <li><Link href="/help" className="hover:text-primary">Help Center</Link></li>
                <li><Link href="/shipping" className="hover:text-primary">Shipping Info</Link></li>
                <li><Link href="/returns" className="hover:text-primary">Returns</Link></li>
                <li><Link href="/faq" className="hover:text-primary">FAQ</Link></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Business Hours</h4>
              <div className="space-y-1 text-sm text-muted-foreground">
                <p>Monday - Saturday: 9AM - 8PM</p>
                <p>Sunday: 10AM - 6PM</p>
                <p className="mt-3 font-semibold">Online Store: 24/7</p>
              </div>
            </div>
          </div>
          
          <div className="border-t mt-8 pt-8 text-center text-muted-foreground">
            <p>© 2024 RU Online Store. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}