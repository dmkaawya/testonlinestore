"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { 
  ShoppingCart, 
  Plus, 
  Minus, 
  Trash2, 
  ArrowLeft, 
  Truck, 
  Shield, 
  RotateCcw,
  CreditCard,
  User,
  Store,
  Phone,
  MapPin,
  MessageCircle
} from "lucide-react"
import Link from "next/link"

interface CartItem {
  id: string
  productId: string
  name: string
  price: number
  marketPrice?: number
  discount?: number
  quantity: number
  image?: string
  color?: string
  size?: string
  stock: number
}

interface CustomerData {
  firstName: string
  lastName: string
  phone: string
  address: string
  district: string
  province: string
}

interface DropshippingData {
  shopName: string
  whatsapp: string
  profit: number
}

export default function CartPage() {
  const [cartItems, setCartItems] = useState<CartItem[]>([])
  const [customerType, setCustomerType] = useState<"retail" | "dropshipping">("retail")
  const [customerData, setCustomerData] = useState<CustomerData>({
    firstName: "",
    lastName: "",
    phone: "",
    address: "",
    district: "",
    province: ""
  })
  const [dropshippingData, setDropshippingData] = useState<DropshippingData>({
    shopName: "",
    whatsapp: "",
    profit: 0
  })
  const [promoCode, setPromoCode] = useState("")
  const [discount, setDiscount] = useState(0)
  const [loading, setLoading] = useState(false)

  const provinces = [
    "Western Province",
    "Central Province", 
    "Southern Province",
    "Northern Province",
    "Eastern Province",
    "North Western Province",
    "North Central Province",
    "Uva Province",
    "Sabaragamuwa Province"
  ]

  const districts = [
    "Colombo", "Gampaha", "Kalutara", "Kandy", "Matale", "Nuwara Eliya",
    "Galle", "Matara", "Hambantota", "Jaffna", "Kilinochchi", "Mannar",
    "Vavuniya", "Mullaitivu", "Batticaloa", "Ampara", "Trincomalee",
    "Kurunegala", "Puttalam", "Anuradhapura", "Polonnaruwa", "Badulla", "Monaragala", "Ratnapura"
  ]

  useEffect(() => {
    loadCart()
  }, [])

  const loadCart = () => {
    const existingCart = JSON.parse(localStorage.getItem('cart') || '[]')
    setCartItems(existingCart)
  }

  const updateQuantity = (itemId: string, newQuantity: number) => {
    if (newQuantity < 1) return
    
    setCartItems(prevItems =>
      prevItems.map(item =>
        item.id === itemId
          ? { ...item, quantity: Math.min(newQuantity, item.stock) }
          : item
      )
    )
  }

  const removeItem = (itemId: string) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== itemId))
  }

  const applyPromoCode = () => {
    if (promoCode.toUpperCase() === "SAVE10") {
      setDiscount(0.1) // 10% discount
    } else if (promoCode.toUpperCase() === "SAVE20") {
      setDiscount(0.2) // 20% discount
    } else {
      setDiscount(0)
    }
  }

  const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0)
  const discountAmount = subtotal * discount
  const shipping = subtotal > 5000 ? 0 : 500 // Free shipping over Rs. 5000
  const tax = subtotal * 0.08 // 8% tax
  const total = subtotal - discountAmount + shipping + tax

  const handleCustomerDataChange = (field: keyof CustomerData, value: string) => {
    setCustomerData(prev => ({ ...prev, [field]: value }))
  }

  const handleDropshippingDataChange = (field: keyof DropshippingData, value: string | number) => {
    setDropshippingData(prev => ({ ...prev, [field]: value }))
  }

  const handleSubmitOrder = async () => {
    // Validate customer data
    if (!customerData.firstName.trim() || !customerData.lastName.trim() || 
        !customerData.phone.trim() || !customerData.address.trim() || 
        !customerData.district || !customerData.province) {
      alert("Please fill in all customer details")
      return
    }

    // Validate dropshipping data if applicable
    if (customerType === "dropshipping") {
      if (!dropshippingData.shopName.trim() || !dropshippingData.whatsapp.trim()) {
        alert("Please fill in all dropshipping details")
        return
      }
    }

    setLoading(true)

    try {
      const orderData = {
        customerType: customerType.toUpperCase(),
        customerName: `${customerData.firstName} ${customerData.lastName}`,
        customerPhone: customerData.phone,
        customerAddress: customerData.address,
        customerDistrict: customerData.district,
        customerProvince: customerData.province,
        shopName: customerType === "dropshipping" ? dropshippingData.shopName : undefined,
        shopWhatsApp: customerType === "dropshipping" ? dropshippingData.whatsapp : undefined,
        total: total,
        profit: customerType === "dropshipping" ? dropshippingData.profit : 0,
        items: cartItems.map(item => ({
          productId: item.productId,
          quantity: item.quantity,
          price: item.price
        }))
      }

      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(orderData)
      })

      if (response.ok) {
        // Clear cart
        localStorage.removeItem('cart')
        setCartItems([])
        
        // Reset form
        setCustomerData({
          firstName: "",
          lastName: "",
          phone: "",
          address: "",
          district: "",
          province: ""
        })
        setDropshippingData({
          shopName: "",
          whatsapp: "",
          profit: 0
        })
        
        alert('Order placed successfully! We will contact you soon.')
      } else {
        alert('Failed to place order. Please try again.')
      }
    } catch (error) {
      console.error('Error placing order:', error)
      alert('Failed to place order. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <ShoppingCart className="h-24 w-24 mx-auto text-muted-foreground" />
          <h1 className="text-2xl font-bold">Your cart is empty</h1>
          <p className="text-muted-foreground">
            Looks like you haven't added any items to your cart yet.
          </p>
          <Button asChild>
            <Link href="/products">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Continue Shopping
            </Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between">
            <div className="flex items-center space-x-4">
              <Link href="/" className="text-2xl font-bold text-primary">
                RU Online Store
              </Link>
              <nav className="hidden md:flex items-center space-x-6">
                <Link href="/products" className="text-sm font-medium hover:text-primary transition-colors">
                  Products
                </Link>
                <Link href="/categories" className="text-sm font-medium hover:text-primary transition-colors">
                  Categories
                </Link>
                <Link href="/deals" className="text-sm font-medium hover:text-primary transition-colors">
                  Deals
                </Link>
                <Link href="/contact" className="text-sm font-medium hover:text-primary transition-colors">
                  Contact
                </Link>
              </nav>
            </div>

            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon">
                <MessageCircle className="h-5 w-5" />
              </Button>
              
              <Button variant="ghost" size="icon" className="relative">
                <ShoppingCart className="h-5 w-5" />
                <Badge className="absolute -top-2 -right-2 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs">
                  {cartItems.length}
                </Badge>
              </Button>
              
              <Button variant="ghost" size="icon">
                <User className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">Shopping Cart</h1>
            <p className="text-muted-foreground">
              {cartItems.length} item{cartItems.length !== 1 ? 's' : ''} in your cart
            </p>
          </div>
          <Button variant="outline" asChild>
            <Link href="/products">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Continue Shopping
            </Link>
          </Button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cartItems.map((item) => (
              <Card key={item.id}>
                <CardContent className="p-6">
                  <div className="flex gap-4">
                    <div className="w-24 h-24 bg-muted rounded-lg flex items-center justify-center flex-shrink-0 overflow-hidden">
                      {item.image ? (
                        <img 
                          src={item.image} 
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span className="text-3xl">📦</span>
                      )}
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h3 className="font-semibold">{item.name}</h3>
                          <div className="flex items-center gap-2 mt-1">
                            {item.color && (
                              <span className="text-sm text-muted-foreground">Color: {item.color}</span>
                            )}
                            {item.size && (
                              <span className="text-sm text-muted-foreground">Size: {item.size}</span>
                            )}
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => removeItem(item.id)}
                          className="text-muted-foreground hover:text-destructive"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            disabled={item.quantity <= 1}
                          >
                            <Minus className="h-4 w-4" />
                          </Button>
                          <Input
                            type="number"
                            value={item.quantity}
                            onChange={(e) => updateQuantity(item.id, parseInt(e.target.value) || 1)}
                            className="w-16 text-center"
                            min={1}
                            max={item.stock}
                          />
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            disabled={item.quantity >= item.stock}
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                          <span className="text-sm text-muted-foreground">
                            {item.stock} available
                          </span>
                        </div>
                        
                        <div className="text-right">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-lg">
                              Rs.{(item.price * item.quantity).toFixed(2)}
                            </span>
                            {item.marketPrice && item.marketPrice > item.price && (
                              <span className="text-sm text-muted-foreground line-through">
                                Rs.{(item.marketPrice * item.quantity).toFixed(2)}
                              </span>
                            )}
                          </div>
                          {item.discount && item.discount > 0 && (
                            <Badge className="bg-red-500 hover:bg-red-500">
                              {item.discount}% OFF
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Order Summary and Checkout Form */}
          <div className="lg:col-span-1 space-y-6">
            {/* Order Summary */}
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>Rs.{subtotal.toFixed(2)}</span>
                  </div>
                  
                  {discount > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span>Discount ({(discount * 100).toFixed(0)}%)</span>
                      <span>-Rs.{discountAmount.toFixed(2)}</span>
                    </div>
                  )}
                  
                  <div className="flex justify-between">
                    <span>Shipping</span>
                    <span>{shipping === 0 ? 'Free' : `Rs.${shipping.toFixed(2)}`}</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span>Tax</span>
                    <span>Rs.{tax.toFixed(2)}</span>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex justify-between font-semibold text-lg">
                    <span>Total</span>
                    <span>Rs.{total.toFixed(2)}</span>
                  </div>
                </div>

                {/* Promo Code */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">Promo Code</label>
                  <div className="flex gap-2">
                    <Input
                      placeholder="Enter promo code"
                      value={promoCode}
                      onChange={(e) => setPromoCode(e.target.value)}
                    />
                    <Button variant="outline" onClick={applyPromoCode}>
                      Apply
                    </Button>
                  </div>
                  {discount > 0 && (
                    <p className="text-sm text-green-600">
                      Promo code applied successfully!
                    </p>
                  )}
                  <p className="text-xs text-muted-foreground">
                    Try: SAVE10 or SAVE20
                  </p>
                </div>

                <div className="text-center">
                  <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                    {shipping === 0 ? "Free Shipping Applied!" : `Free shipping on orders over Rs.5000`}
                  </Badge>
                </div>
              </CardContent>
            </Card>

            {/* Customer Type Selection */}
            <Card>
              <CardHeader>
                <CardTitle>Customer Type</CardTitle>
              </CardHeader>
              <CardContent>
                <RadioGroup value={customerType} onValueChange={(value) => setCustomerType(value as "retail" | "dropshipping")}>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="retail" id="retail" />
                    <Label htmlFor="retail" className="flex items-center gap-2">
                      <User className="h-4 w-4" />
                      Retail Customer
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="dropshipping" id="dropshipping" />
                    <Label htmlFor="dropshipping" className="flex items-center gap-2">
                      <Store className="h-4 w-4" />
                      Dropshipping Partner
                    </Label>
                  </div>
                </RadioGroup>
              </CardContent>
            </Card>

            {/* Customer Information Form */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Customer Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name *</Label>
                    <Input
                      id="firstName"
                      value={customerData.firstName}
                      onChange={(e) => handleCustomerDataChange('firstName', e.target.value)}
                      placeholder="First name"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name *</Label>
                    <Input
                      id="lastName"
                      value={customerData.lastName}
                      onChange={(e) => handleCustomerDataChange('lastName', e.target.value)}
                      placeholder="Last name"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number *</Label>
                  <Input
                    id="phone"
                    value={customerData.phone}
                    onChange={(e) => handleCustomerDataChange('phone', e.target.value)}
                    placeholder="+94 XX XXX XXXX"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address">Address *</Label>
                  <Textarea
                    id="address"
                    value={customerData.address}
                    onChange={(e) => handleCustomerDataChange('address', e.target.value)}
                    placeholder="Full address"
                    rows={3}
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="district">District *</Label>
                    <Select value={customerData.district} onValueChange={(value) => handleCustomerDataChange('district', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select district" />
                      </SelectTrigger>
                      <SelectContent>
                        {districts.map((district) => (
                          <SelectItem key={district} value={district}>
                            {district}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="province">Province *</Label>
                    <Select value={customerData.province} onValueChange={(value) => handleCustomerDataChange('province', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select province" />
                      </SelectTrigger>
                      <SelectContent>
                        {provinces.map((province) => (
                          <SelectItem key={province} value={province}>
                            {province}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Dropshipping Information (Conditional) */}
            {customerType === "dropshipping" && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Store className="h-5 w-5" />
                    Dropshipping Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="shopName">Shop Name *</Label>
                    <Input
                      id="shopName"
                      value={dropshippingData.shopName}
                      onChange={(e) => handleDropshippingDataChange('shopName', e.target.value)}
                      placeholder="Your shop name"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="whatsapp">WhatsApp Number *</Label>
                    <Input
                      id="whatsapp"
                      value={dropshippingData.whatsapp}
                      onChange={(e) => handleDropshippingDataChange('whatsapp', e.target.value)}
                      placeholder="+94 XX XXX XXXX"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="profit">Your Profit (Rs.)</Label>
                    <Input
                      id="profit"
                      type="number"
                      value={dropshippingData.profit}
                      onChange={(e) => handleDropshippingDataChange('profit', parseFloat(e.target.value) || 0)}
                      placeholder="0.00"
                      min="0"
                      step="0.01"
                    />
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Place Order Button */}
            <Button 
              onClick={handleSubmitOrder}
              className="w-full" 
              size="lg"
              disabled={loading}
            >
              {loading ? "Processing..." : (
                <>
                  <CreditCard className="h-4 w-4 mr-2" />
                  Place Order • Rs.{total.toFixed(2)}
                </>
              )}
            </Button>

            {/* Contact Info */}
            <div className="text-center space-y-2 text-sm text-muted-foreground">
              <p>📞 Hotline: 765767113</p>
              <p>📱 WhatsApp: +94 77 504 8455</p>
              <p>✉️ Email: ru.online.stores@gmail.com</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}