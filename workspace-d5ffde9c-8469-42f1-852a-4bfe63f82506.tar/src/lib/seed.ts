import { db } from './db'

async function main() {
  // Create categories
  const electronics = await db.category.create({
    data: {
      name: 'Electronics',
      description: 'Electronic devices and gadgets'
    }
  })

  const fashion = await db.category.create({
    data: {
      name: 'Fashion',
      description: 'Clothing and accessories'
    }
  })

  const home = await db.category.create({
    data: {
      name: 'Home & Garden',
      description: 'Home decor and garden items'
    }
  })

  // Create sample products
  const products = [
    {
      name: 'Wireless Bluetooth Headphones',
      shortTitle1: 'Premium Sound Quality',
      shortTitle2: 'Long Battery Life',
      price: 8999.00,
      marketPrice: 12999.00,
      discount: 30,
      color: 'Black',
      stock: 15,
      categoryId: electronics.id,
      image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=400&h=400&fit=crop',
      description: 'High-quality wireless headphones with noise cancellation and premium sound quality.'
    },
    {
      name: 'Smart Watch Pro',
      shortTitle1: 'Fitness Tracker',
      shortTitle2: 'Health Monitor',
      price: 24999.00,
      marketPrice: 34999.00,
      discount: 28,
      color: 'Silver',
      stock: 8,
      categoryId: electronics.id,
      image: 'https://images.unsplash.com/photo-1544117519-31a4b719223d?w=400&h=400&fit=crop',
      description: 'Advanced smartwatch with health monitoring, GPS, and fitness tracking features.'
    },
    {
      name: 'Cotton T-Shirt Premium',
      shortTitle1: '100% Cotton',
      shortTitle2: 'Comfortable Fit',
      price: 1299.00,
      marketPrice: 1999.00,
      discount: 35,
      color: 'White',
      size: 'L',
      stock: 25,
      categoryId: fashion.id,
      image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=400&fit=crop',
      description: 'Premium quality cotton t-shirt with comfortable fit and durable fabric.'
    },
    {
      name: 'Designer Handbag',
      shortTitle1: 'Genuine Leather',
      shortTitle2: 'Spacious Design',
      price: 8999.00,
      marketPrice: 14999.00,
      discount: 40,
      color: 'Brown',
      stock: 5,
      categoryId: fashion.id,
      image: 'https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=400&h=400&fit=crop',
      description: 'Elegant designer handbag made from genuine leather with spacious compartments.'
    },
    {
      name: 'LED Desk Lamp',
      shortTitle1: 'Adjustable Brightness',
      shortTitle2: 'Modern Design',
      price: 3499.00,
      marketPrice: 4999.00,
      discount: 30,
      color: 'White',
      stock: 12,
      categoryId: home.id,
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop',
      description: 'Modern LED desk lamp with adjustable brightness and flexible neck design.'
    },
    {
      name: 'Indoor Plant Set',
      shortTitle1: 'Air Purifying',
      shortTitle2: 'Low Maintenance',
      price: 2499.00,
      marketPrice: 3999.00,
      discount: 37,
      stock: 18,
      categoryId: home.id,
      image: 'https://images.unsplash.com/photo-1485955900006-10f4d9d67412?w=400&h=400&fit=crop',
      description: 'Beautiful set of indoor plants that help purify air and require minimal maintenance.'
    }
  ]

  for (const productData of products) {
    await db.product.create({
      data: productData
    })
  }

  console.log('Database seeded successfully!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })